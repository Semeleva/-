﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace steklopaketzadacha
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int a = Convert.ToInt32(textBox1.Text);
            int b = Convert.ToInt32(textBox2.Text);
            int s = a * b;

            s = s * 4;

            if (comboBox1.SelectedIndex == 0)
            {
                s = s + 1000;
            }
            if (comboBox1.SelectedIndex == 1)
            {
                s = s + 3000;
            }

            if (checkBox1.Checked) { s = s + 500; }
            if (checkBox2.Checked) { s = s + 700; }
            if (checkBox3.Checked) { s = s + 900; }

            oplata.Text = Convert.ToString(s);
        }
    }
    
}
