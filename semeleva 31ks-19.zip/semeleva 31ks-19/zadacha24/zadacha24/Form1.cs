﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zadacha24
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\79999\OneDrive\Рабочий стол\semeleva\zadacha24\1.jpg");
                label3.Text = ("300000");

            }
            if (radioButton2.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\79999\OneDrive\Рабочий стол\semeleva\zadacha24\2.jpg");
                label3.Text = ("500000");

            }
            if (radioButton3.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\79999\OneDrive\Рабочий стол\semeleva\zadacha24\3.jpg");
                label3.Text = ("800000");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
